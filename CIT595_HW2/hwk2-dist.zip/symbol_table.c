#include <stdio.h>
#include <string.h>

extern int parse_function_header(char*);
extern int parse_line(char*);
extern char* function_name;
extern char* parameter_names[10];
extern char* variable_names[10];

/*
 * THIS IS THE STARTER CODE FOR PART 1 
 */

int add_symbol(char* symbol, int offset) {
  // IMPLEMENT THIS IN STEP 1
  return -1;
}

int get_offset(char* symbol, int* offset) {
  // IMPLEMENT THIS IN STEP 1
  return -1;
}

void clear() {
  // IMPLEMENT THIS IN STEP 1
}

int populate_symbol_table(char* filename) {
  // IMPLEMENT THIS IN STEP 2
  return -1;
}
